
local smallhydroelectricturbinerecipe = table.deepcopy(data.raw.recipe["heavy-armor"])
smallhydroelectricturbinerecipe.enabled = true
recipe.name = "small-hydroelectric-turbine"
recipe.result = "small-hydroelectric-turbine"

data:extend{smallhydroelectricturbinerecipe}