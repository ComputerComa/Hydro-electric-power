data:extend({
    {
        type = "bool-setting",
        name = "hydro-power-use-old-power-ratios",
        setting_type = "startup",
        default_value = false
    }
})